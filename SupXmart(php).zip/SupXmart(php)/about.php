<?php
// include header.php file
include ('header.php');

?>

about



<?php

// include footer.php file
include ('footer.php');
?>