<?php
// include header.php file
include ('header.php');


// database connection
include ('connection.php');

?>
<?php

if(!empty($_POST['submit'])){

  if(!empty($_POST['firstname'])){
      $fname = $_POST['firstname'];
      $lname = $_POST['lastname'];
      $email = $_POST['email'];
      $contact = $_POST['contactno'];
      $message = $_POST['message'];

      $sql = "INSERT INTO contact (sno, fname, lname, email,contact,message)
      VALUES (' ','$fname','$lname','$email','$contact','$message')";
      






       $run = mysqli_query($conn, $sql) or die(mysqli_error($conn));
      if ($run) {
      echo "New record created successfully";
        } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
        }
  }
}
$conn->close();



?>




<!-- htlm code -->
<div style="display:flex;">

<div class="container1" style="margin:100px 100px;width:600px">
  <form action="contact.php" method="POST">

    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="email">Email</label>
    <input type="email" id="email" name="email" placeholder="Your email..">
    
    <label for="contactno">Contact</label>
    <input type="text" id="contactno" name="contactno" placeholder="Your Contact number..">

    <label for="message">Message</label>
    <textarea id="message" name="message" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" name="submit" value="Submit">

  </form>
</div>
<div style="margin:100px">
<h1>Have Some Question ? </h1><br>
<em>Keep In Touch</em><br>
<img src="assets/contact.jpg" alt="" width="500px" height="500px" style="margin-top:40px;margin-bottom:40px">
<h1>Location</h1><br>
<em>06, Natkur, Sarojni Nagar, Lucknow (+91 8318188171)</em><br>
</div> 
</div>   

<?php

// include footer.php file
include ('footer.php');
?>