<!-- database connection -->

<?php
$servername = "localhost:8089";
$username = "root";
$password = "";
$db = "shopee";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>