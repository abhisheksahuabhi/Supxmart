<?php
// include header.php file
include ('header.php');

// database connection
include ('connection.php');
?>



<!-- session code -->

<?php
   
  
   
  if ( isset($_POST['submit'])){

          
          // $username = $_POST['username'];
          $email = $_POST['email'];
          $password = $_POST['password'];


          $sql = "SELECT * FROM user WHERE email = '$email' && password = '$password' ";

          $query_run = mysqli_query($conn, $sql);

          $row = mysqli_num_rows($query_run);
    
            if($row == 1){
               ?>
               <script>
                 alert("LogIn successful");
               </script> 
              <?php
                $_SESSION['email'] = $email;
               // my code
                    if ($row > 0) {
                      // output data of each row
                      while($row = mysqli_fetch_assoc($query_run)) {
                      // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
                        $_SESSION['user_id'] = $row["user_id"];
                        $_SESSION['first_name'] = $row["first_name"];

                      }
                    } 
              // my code end  
                header('location:index.php');
            }else{
               ?>
               <script>
                 alert("LogIn failed");
               </script> 
            <?php
             header('location:login.php');
            }

          

  }


?>


<!-- login form -->
<center>

<h1 style="margin-top:50px;color:steelblue"><u>LOGIN</u></h1>
<div class="container1" style="margin:40px 100px;width:600px;">
  <form action="login.php" method="POST" >

    <label for="email">Email</label>
    <input type="email" id="email" name="email" placeholder="Your email.." required>
    
    <label for="password">password</label>
    <input type="text" id="password" name="password" placeholder="Your password.." required>
  
    <input type="submit" name="submit" value="Submit">
    <p style="padding-top:10px;">Create new account <a href="signup.php">Sign Up</a>  </p>
  </form>
</div>
</center>


<?php

// include footer.php file
include ('footer.php');
?>