<?php
// include header.php file
include ('header.php');

// database connection
include ('connection.php');
?>
<!-- signup php code -->
<?php 

  if(isset($_POST['submit'])){
          $first_name = $_POST['first_name'];
          $last_name = $_POST['last_name'];
          $email = $_POST['email'];
          $password = $_POST['password'];

          $checkuser ="SELECT * from user where email='$email'";
          $query_run = mysqli_query($conn, $checkuser);
          $row = mysqli_num_rows($query_run);
          if($row>0){
            echo "user already exist !!";
          }
          else{
            $sql = "INSERT into user (user_id,first_name,last_name,email,password,register_date) values (' ','$first_name','$last_name','$email','$password','')";
            $run = mysqli_query($conn, $sql) or die(mysqli_error($conn));
                if ($run) {
                echo "New user created !! Please Login now";
                  } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                  }
          }

  }
  $conn->close();

?>

<!-- signup form -->
<center>

<h1 style="margin-top:50px;color:steelblue"><u>SIGN UP</u></h1>
<div class="container1" style="margin:40px 100px;width:600px;">
  <form action="signup.php" method="POST" >

    <label for="first_name">first_name</label>
    <input type="text" id="first_name" name="first_name" placeholder="Your first_name.." required>
    
    <label for="last_name">last_name</label>
    <input type="text" id="last_name" name="last_name" placeholder="Your last_name.." required>

    <label for="email">Email</label>
    <input type="email" id="email" name="email" placeholder="Your email.." required>
    
    <label for="password">password</label>
    <input type="text" id="password" name="password" placeholder="Your password.." required>


    <input type="submit" name="submit" value="Submit">
    <p style="padding-top:10px;">Alreday account <a href="login.php">Log in</a>  </p>
  </form>
</div>
</center>



<?php

// include footer.php file
include ('footer.php');
?>