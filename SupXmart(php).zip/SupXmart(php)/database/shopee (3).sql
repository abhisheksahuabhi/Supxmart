-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8089
-- Generation Time: Dec 19, 2021 at 04:32 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopee`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `item_id`) VALUES
(43, 2, 15),
(45, 1, 3),
(46, 2, 7);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `sno` int(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`sno`, `fname`, `lname`, `email`, `contact`, `message`) VALUES
(1, 'h', 'j', 'j@gmail.com', '23', 'hi'),
(2, 'atul', 'sahu', 'atul@gmail.com', '6464646', 'hi'),
(3, 'a', 'a', 'a@gmail.com', '12345', 'a'),
(4, 'f', 'f', 'f@gmail.com', '7', 'f'),
(5, 'q', 'q', 'q@gmail.com', '12', 'q');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `item_id` int(11) NOT NULL,
  `item_brand` varchar(200) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `item_register` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`item_id`, `item_brand`, `item_name`, `item_price`, `item_image`, `item_register`) VALUES
(1, 'Grocery', 'Fortune', 152.00, './assets/products/1.png', '2020-03-28 11:08:57'),
(2, 'Softdrink', 'Pepsi (1 ltr )', 90.00, './assets/products/2.png', '2020-03-28 11:08:57'),
(3, 'Grocery', 'Basmati Rice', 160.00, './assets/products/3.png', '2020-03-28 11:08:57'),
(4, 'PetFood', 'Dog Food', 100.00, './assets/products/4.png', '2020-03-28 11:08:57'),
(5, 'Grocery', 'Knorr Soup', 50.00, './assets/products/5.png', '2020-03-28 11:08:57'),
(6, 'Grocery', 'Chings Noodles ( 75 gm )', 60.00, './assets/products/6.png', '2020-03-28 11:08:57'),
(7, 'Grocery', 'Premium Bake Rusk (300 Gm)', 75.00, './assets/products/8.png', '2020-03-28 11:08:57'),
(8, 'Fruit', 'Mango ( 2 kg )', 220.00, './assets/products/10.png', '2020-03-28 11:08:57'),
(9, 'Fruit', 'Apple (2 kg )', 300.00, './assets/products/11.png', '2020-03-28 11:08:57'),
(10, 'Vegetable', 'Fresh Broccoli (500 Gm)', 140.00, './assets/products/12.png', '2020-03-28 11:08:57'),
(11, 'Softdrink', 'Mixed Fruit Juice (1 Ltr)', 100.00, './assets/products/13.png', '2020-03-28 11:08:57'),
(12, 'Softdrink', 'Prune Juice - Sunsweet (1 Ltr)', 80.00, './assets/products/14.png', '2020-03-28 11:08:57'),
(13, 'Softdrink', 'Coco Cola Zero Can (330 Ml)', 45.00, './assets/products/15.png', '2020-03-28 11:08:57'),
(14, 'Grocery', 'Lahsun Sev (150 Gm)', 40.00, './assets/products/7.png', '2020-03-28 11:08:57'),
(15, 'Vegetable', 'Fresh Spinach (Palak)', 122.00, './assets/products/9.png', '2020-03-28 11:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `email`, `password`, `register_date`) VALUES
(1, 'atul', 'sahu', 'atul@gmail.com', '12345', '2020-03-28 13:07:17'),
(2, 'Akshay', 'Kashyap', 'a@gmail.com', '12', '2020-03-28 13:07:17'),
(3, 'Abhishek', 'Sahu', 'abhishek@gmail.com', '123', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`cart_id`, `user_id`, `item_id`) VALUES
(28, 1, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `sno` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
